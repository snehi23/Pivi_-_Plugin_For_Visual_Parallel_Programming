package asu.ser.capstone.pivi;

/**
 * @model
 */
public interface StatementOutput {
	/**
	 * @model
	 */
	public Statement getStatement();
	
	/**
	 * @model
	 */
	public End getEnd();
}
