package asu.ser.capstone.pivi;

import java.util.List;

/**
 * @model
 */
public interface End {
	
	/**
	 * @model
	 */
	public List<StatementOutput> getStatementOutput();
}
