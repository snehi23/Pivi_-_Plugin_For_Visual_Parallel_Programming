package asu.ser.capstone.pivi;

/**
 * @model
 */
public interface WhileStatement extends Statement{

}
