package asu.ser.capstone.pivi;

import java.util.List;

/**
 * @model
 */
public interface Start {
	/**
	 * @model
	 */
	public List<StatementInput> getInputs();
}
