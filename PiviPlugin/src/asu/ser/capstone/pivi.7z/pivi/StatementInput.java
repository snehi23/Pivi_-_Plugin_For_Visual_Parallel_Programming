package asu.ser.capstone.pivi;

/**
 * @model
 */
public interface StatementInput {
	
	/**
	 * @model
	 */
	public Statement getStatement();
	
	/**
	 * @model
	 */
	public Start getStart();
}
