package asu.ser.capstone.pivi;

/**
 * @model
 */
public interface IfStatement extends Statement{

}
