package asu.ser.capstone.pivi;

/**
 * @model
 */
public interface InstructionStatement extends Statement{

}
